export interface CustomerDto {
	id: number;
	name: string;
	surname: string;
	email: string;
}
