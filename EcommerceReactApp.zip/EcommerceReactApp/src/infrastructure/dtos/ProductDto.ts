export interface ProductDto {
	id: number;
	categoryId: number;
	name: string;
	description: string;
	price: number;
}
