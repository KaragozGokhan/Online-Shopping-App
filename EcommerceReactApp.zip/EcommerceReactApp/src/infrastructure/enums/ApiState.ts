enum ApiState {
	Idle = 'idle',
	Fulfilled = 'fulfilled',
	Pending = 'pending',
	Rejected = 'rejected',
	Settled = 'settled',
}

export default ApiState;
